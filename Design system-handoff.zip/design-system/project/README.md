# Fatax Growth · Design System

> **Disciplined Energy.** Sistema de design da Fatax — braço direito do empresário em gestão, marketing e vendas.

Versão: **0.5.0** · Codename: **Dark Cockpit** · Atualizado: 25 mai 2026

---

## Estrutura do repo

```
.
├── DESIGN.md                  ← spec canônico (frontmatter YAML + narrativa)
├── README.md                  ← este arquivo
├── package.json
│
├── dist/                      ← @fatax/design-system (CSS + sidebar)
│   ├── tokens.css             ·  variáveis CSS  (⚡ gerado por codegen/)
│   ├── base.css               ·  reset + type + document shell
│   ├── components.css         ·  btn, card, pill, spec-table, ...
│   ├── sidebar.css            ·  sidebar recolhível + lockup
│   ├── fatax.css              ·  bundle (importa os 4 acima)
│   ├── sidebar.html           ·  template com sprite (28 ícones)
│   ├── sidebar.js             ·  collapse + ⌘K + active link
│   ├── tailwind.config.js     ·  ⚡ gerado por codegen/
│   ├── tokens.dtcg.json       ·  ⚡ gerado por codegen/ (W3C / Figma)
│   └── README.md
│
├── react/                     ← @fatax/design-system-react (componentes tipados)
│   ├── src/                   ·  Button, Pill, Card, Stat, Sidebar, ...
│   ├── package.json
│   └── README.md
│
├── codegen/                   ← @fatax/codegen (DESIGN.md → outputs)
│   ├── generate.mjs           ·  lê YAML, gera CSS + Tailwind + DTCG
│   ├── package.json
│   └── README.md
│
├── stylelint/                 ← @fatax/stylelint-config (regras Fatax)
│   ├── index.json             ·  config compartilhável
│   ├── package.json
│   └── README.md
│
├── visual/                    ← @fatax/visual-regression (Playwright)
│   ├── tests/                 ·  brandbook + example + states
│   ├── snapshots/             ·  baselines pixel-perfect
│   ├── playwright.config.ts
│   ├── package.json
│   └── README.md
│
├── .github/workflows/         ← CI
│   ├── lint.yml               ·  stylelint em todo PR
│   ├── tokens-check.yml       ·  drift DESIGN.md ↔ dist/
│   └── visual.yml             ·  Playwright snapshots
│
├── .stylelintrc.json          ← root config (extends stylelint/)
├── .stylelintignore
│
├── assets/
│   └── logo/                  ·  7 SVGs oficiais
│       ├── logo-fatax-wordmark-{cream,black,onorange}.svg
│       ├── logo-fatax-mark-{cream,black,onorange}.svg
│       └── logo-fatax-mono.svg
│
├── brandbook/                 ← brandbook interativo (24 páginas)
│   ├── index.html             ·  capa
│   ├── 01-overview.html … 24-accessibility.html
│   └── shared/                ·  fonte original (dist/ é derivado daqui)
│
└── examples/
    ├── minimal.html           ·  app vanilla consumindo dist/
    └── react-snippet.tsx      ·  código de referência React (não runnable solo)
```

---

## Como usar em outro projeto

O repo exporôe **cinco pacotes** — cada um com seu próprio `package.json`:

| Pacote | Pra quê |
|---|---|
| **`@fatax/design-system`** (raiz, `dist/`) | CSS + sidebar HTML/JS. Funciona em qualquer stack (vanilla, React, Vue, Next, Astro, etc). |
| **`@fatax/design-system-react`** (`react/`) | Componentes React tipados sobre o CSS. Use em apps React/Next. |
| **`@fatax/codegen`** (`codegen/`) | Script que regenera `dist/tokens.css`, `dist/tailwind.config.js` e `dist/tokens.dtcg.json` a partir do YAML do `DESIGN.md`. Rodar quando você editar tokens. |
| **`@fatax/stylelint-config`** (`stylelint/`) | Config Stylelint compartilhável. Bloqueia hex fora da paleta, fontes fora da dupla, gradientes na marca, etc. Toda app Fatax estende. |
| **`@fatax/visual-regression`** (`visual/`) | Playwright suite com 36 snapshots pixel-a-pixel (24 páginas do brandbook + estados interativos). CI bloqueia merge em qualquer drift visual. |

### Opção 1 · Git submodule (mais simples, vanilla CSS)

```bash
git submodule add git@github.com:fatax/design-system.git vendor/design-system
```

No HTML do seu app:

```html
<link rel="stylesheet" href="vendor/design-system/dist/fatax.css" />
<script src="vendor/design-system/dist/sidebar.js"></script>
```

Cole o markup do `vendor/design-system/dist/sidebar.html`, preencha o `<nav>` conforme as rotas do seu app. **Não remova** o `.poweredby` do rodapé — é obrigatório.

### Opção 2 · GitHub Packages (npm privado)

`.npmrc` na raiz do seu app:

```
@fatax:registry=https://npm.pkg.github.com/
```

```bash
npm install @fatax/design-system
```

Importe os CSS (Vite, Next, Webpack, etc):

```js
import '@fatax/design-system';                       // bundle
// ou seletivo:
import '@fatax/design-system/tokens';
import '@fatax/design-system/base';
import '@fatax/design-system/components';
import '@fatax/design-system/sidebar.css';
```

Script:

```html
<script src="/node_modules/@fatax/design-system/dist/sidebar.js"></script>
```

### Opção 4 · React (Next, Vite, CRA)

```bash
npm install @fatax/design-system @fatax/design-system-react
```

```tsx
import '@fatax/design-system';
import { Sidebar, Button, SectionHeader, Stat, applySidebarStateEarly } from '@fatax/design-system-react';

applySidebarStateEarly(); // evita flash do sidebar

function App() {
  return (
    <div className="app">
      <Sidebar groups={[/* ... */]} />
      <main className="main">
        <SectionHeader eyebrow="Dashboard" title="Receita" />
        <Button variant="primary">Ação</Button>
      </main>
    </div>
  );
}
```

Doc completa: [`react/README.md`](./react/README.md).  
Snippet copy-paste: [`examples/react-snippet.tsx`](./examples/react-snippet.tsx).

---

## Codegen — single source of truth

O `DESIGN.md` é a fonte. `codegen/` lê o YAML do frontmatter e gera:

```
DESIGN.md  ├─→ dist/tokens.css            (CSS custom properties)
           ├─→ dist/tailwind.config.js    (theme.extend pronto)
           └─→ dist/tokens.dtcg.json      (W3C · Figma Tokens Studio)
```

```bash
cd codegen
npm install
npm run generate     # gera tudo
npm run check        # CI: falha se houver drift
```

No seu app Tailwind:

```js
// tailwind.config.js
import fataxConfig from '@fatax/design-system/dist/tailwind.config.js';
export default { ...fataxConfig, content: ['./src/**/*.{ts,tsx}'] };
```

Doc completa: [`codegen/README.md`](./codegen/README.md).

---

## Lint — a polícia do design system

`@fatax/stylelint-config` traduz as regras do `DESIGN.md` em **rules automáticas**. PR vermelho → não merga.

### Em qualquer app Fatax:

```bash
npm install --save-dev @fatax/stylelint-config stylelint
```

`.stylelintrc.json`:
```json
{ "extends": ["@fatax/stylelint-config"] }
```

`package.json`:
```json
{
  "scripts": {
    "lint:css": "stylelint 'src/**/*.css'",
    "lint:css:fix": "stylelint 'src/**/*.css' --fix"
  }
}
```

### O que bloqueia:

| | Bloqueia | Permite |
|---|---|---|
| **Hex literal** | `#FF4800`, `#0A0A0A` em código de produto | `var(--brand-orange)` etc |
| **Cinzas frios** | `#000`, `#888`, `#444`, `gray` | warm-grays via `var(--text-*)` |
| **Fontes** | Roboto, Helvetica, Playfair, Open Sans, Lato, Poppins, etc | `var(--font-*)`, Syne, Inter, JetBrains Mono |
| **Duration** | `transition: 250ms` | `var(--dur-fast/base/slow/deliberate)` |
| **Easing** | `ease-in-out` | `var(--ease-out/std/in)` |
| **Gradient laranja** | `linear-gradient(..., #FF4800, ...)` | nada — laranja é sólido |
| **Box-shadow** | `box-shadow: 0 4px 12px ...` | `none` (Fatax usa contraste, não sombra) |

Doc completa: [`stylelint/README.md`](./stylelint/README.md).

---

## Visual regression — pixel-perfect guardrail

`@fatax/visual-regression` roda Playwright contra **36 snapshots** das páginas do brandbook + estados interativos críticos. Drift visual é detectado antes de chegar em produção.

```bash
cd visual
npm install
npm run install:browsers   # baixa chromium uma vez
npm test                   # roda regressão contra baselines
npm run test:update        # atualiza baselines (mudanças intencionais)
npm run test:ui            # modo interativo (debug)
```

**Baselines em Ubuntu** (paridade com CI):
```bash
docker run --rm --network host -v "$(pwd):/work" -w /work/visual \
  mcr.microsoft.com/playwright:v1.40.0-jammy \
  bash -c "npm install && npm run test:update"
```

Doc completa: [`visual/README.md`](./visual/README.md).

---

## CI — três jobs automáticos

Na raiz, `.github/workflows/` tem:

### `lint.yml` — stylelint em todo PR/push
Roda `npm run lint:css`. PR com CSS fora das regras Fatax fica vermelho.

### `tokens-check.yml` — drift entre `DESIGN.md` e `dist/`
Roda `codegen --check`. Se você editou o YAML do `DESIGN.md` mas não rodou `npm run tokens:generate`, o CI sinaliza com mensagem clara.

### `visual.yml` — visual regression no PR
Roda Playwright contra os 36 baselines. Falha → sobe o `playwright-report` como artifact + comenta no PR com instruções Docker pra atualizar baselines.

### Scripts no `package.json` raiz:

```bash
npm run lint:css           # lint local
npm run lint:css:fix       # auto-fix onde possível
npm run tokens:generate    # regenera dist/tokens.* a partir do DESIGN.md
npm run tokens:check       # verifica drift (usado pelo CI)
npm run check              # roda tokens:check + lint:css
```

---

## Exemplo mínimo

Veja `examples/minimal.html` — app completa em ~150 linhas, zero CSS custom, sidebar funcional + topbar + section header + stats + botões + pills.

---

## Subindo no GitHub

```bash
git init
git add .
git commit -m "v0.5.0 · Dark Cockpit (extração inicial do brandbook)"
git branch -M main
git remote add origin git@github.com:fatax/design-system.git
git push -u origin main
git tag v0.5.0 && git push --tags
```

Depois, em **GitHub → Settings → Packages**, habilite o GitHub Packages registry pra publicar como `@fatax/design-system`. Comando: `npm publish` (já configurado no `package.json`).

---

## Regras inegociáveis

Toda app powered-by-Fatax **DEVE**:

1. Carregar `tokens.css` antes de qualquer estilo próprio.
2. Incluir o sidebar com o lockup **"Powered by Fatax Growth"** no rodapé.
3. Usar exclusivamente as 3 famílias tipográficas (Syne · Inter · JetBrains Mono).
4. Texto sobre laranja = **branco**, nunca preto.
5. Botões com `white-space: nowrap` — nunca quebram linha.
6. Preto base = `#0A0A0A`, nunca `#000` puro.
7. Apenas **1 ação primária** (laranja) por tela.
8. Nada de cinzas frios (`#888`, `#444`). Tudo é warm-gray.

Detalhes completos: `DESIGN.md` na raiz.

---

## Versionamento (semver)

- `patch` (`0.5.x`) — fix visual, bug, ajuste de contraste
- `minor` (`0.x.0`) — token ou componente novo (backward-compatible)
- `major` (`x.0.0`) — remoção/renomeação (quebra consumers)

Cada release tem entrada no `DESIGN.md §17 (changelog)`.

---

## Brandbook navegável

Para explorar o sistema visualmente, abra `brandbook/index.html` — 24 páginas cobrindo fundamentos, expressão, design system, showcase e práticas.

---

## Próximos passos (roadmap interno)

- [x] Pacote React tipado (`@fatax/design-system-react`) — **26 componentes** cobrindo dashboard completo
- [x] Codegen Tailwind + DTCG a partir do `DESIGN.md` (`@fatax/codegen`)
- [x] Stylelint config com regras Fatax (`@fatax/stylelint-config`)
- [x] GitHub Actions: `lint.yml` + `tokens-check.yml` + `visual.yml`
- [x] Visual regression (Playwright) nas páginas do brandbook (`@fatax/visual-regression`)
- [x] Componentes faltantes: Radio, Tooltip, Drawer, Avatar, Alert, Skeleton, Spinner, EmptyState, ErrorState
- [ ] CLI `create-fatax-app` para scaffolding de novos produtos
- [ ] Promover componentes avançados ao `DESIGN.md` como spec canônico (Input, Toggle, Select, Tabs, Modal, Drawer, Datepicker, Sparkline, Funnel, Alert, Avatar, Skeleton, Spinner, EmptyState, Tooltip)

---

**Internal use · Fatax Growth · 2026**
